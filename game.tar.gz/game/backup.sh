#!/bin/sh
clear
echo -e "\033[0;36m 
Hi, Files is backing up!\n
Please Wait...\033[0m"
cd /usr/game/ && sh clear.sh
cd /usr && tar cvzf `date +"%d-%m-%Y"`myte2-game-yedek.tar.gz game
cd /var/db && tar cvzf `date +"%d-%m-%Y"`myte2-mysql-yedek.tar.gz mysql
clear
echo -e "\033[0;36m 
Backup Succeeded\033[0m"