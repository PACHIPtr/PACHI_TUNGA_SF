#!/bin/sh
./vrunner --kill --pid-path pid.db >> autorun.log 2>&1