#!/bin/sh
./db >> autorun.log 2>&1 &