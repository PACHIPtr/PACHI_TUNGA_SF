#!/bin/sh
./vrunner --kill --pid-path=pid.game >> autorun.log 2>&1