#!/bin/sh
./vrunner --daemon --pid-path=pid.game --file=game >> autorun.log 2>&1 &
