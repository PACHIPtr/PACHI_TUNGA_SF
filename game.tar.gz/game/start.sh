#!/bin/sh

cd /usr/game/share/bin
chmod -R 777 game
chmod -R 777 db
cd /usr/game
sh clear.sh

echo -e "\033[0;36m  
Arven2|Myte2 Server Files \n
Author : PACHI || Tunga\n
######################################## \n
How many channels would you like to start? \n
1 - 1 Channel\n 
2 - 2 Channel\n
3 - 3 Channel\n
4 - 4 Channel\n
5 - 5 Channel\n
6 - 6 Channel\n"

read chs

case $chs in 
1*) 

	echo -e "\033[1;32mDatabase is starting...\033[0m"
	cd /usr/game/cores/db/
	sh run.sh
	sleep 2
	clear
	echo -e "\033[1;32m \nAuth is starting...\033[0m"
	cd /usr/game/cores/auth/
	sh run.sh
	sleep 2
	clear
	echo -e "\033[1;32m \nChannel (1.1) is starting...\033[0m"
	cd /usr/game/cores/channel1/core1/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (1.2) is starting...\033[0m"
	cd /usr/game/cores/channel1/core2/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (1.3) is starting...\033[0m"
	cd /usr/game/cores/channel1/core3/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (99) is starting...\033[0m"
	cd /usr/game/cores/channel99/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel 1 is Live!\033[0m"
;;
2*)

	echo -e "\033[1;32mDatabase is starting...\033[0m"
	cd /usr/game/cores/db/
	sh run.sh
	sleep 2
	clear
	echo -e "\033[1;32m \nAuth is starting...\033[0m"
	cd /usr/game/cores/auth/
	sh run.sh
	sleep 2
	clear
	echo -e "\033[1;32m \nChannel (1.1) is starting...\033[0m"
	cd /usr/game/cores/channel1/core1/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (1.2) is starting...\033[0m"
	cd /usr/game/cores/channel1/core2/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (1.3) is starting...\033[0m"
	cd /usr/game/cores/channel1/core3/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (2.1) is starting...\033[0m"
	cd /usr/game/cores/channel2/core1/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (2.2) is starting...\033[0m"
	cd /usr/game/cores/channel2/core2/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (2.3) is starting...\033[0m"
	cd /usr/game/cores/channel2/core3/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (99) is starting...\033[0m"
	cd /usr/game/cores/channel99/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel 2 is Live!\033[0m"
	
	
;;
3*)

	echo -e "\033[1;32mDatabase is starting...\033[0m"
	cd /usr/game/cores/db/
	sh run.sh
	sleep 2
	clear
	echo -e "\033[1;32m \nAuth is starting...\033[0m"
	cd /usr/game/cores/auth/
	sh run.sh
	sleep 2
	clear
	echo -e "\033[1;32m \nChannel (1.1) is starting...\033[0m"
	cd /usr/game/cores/channel1/core1/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (1.2) is starting...\033[0m"
	cd /usr/game/cores/channel1/core2/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (1.3) is starting...\033[0m"
	cd /usr/game/cores/channel1/core3/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (2.1) is starting...\033[0m"
	cd /usr/game/cores/channel2/core1/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (2.2) is starting...\033[0m"
	cd /usr/game/cores/channel2/core2/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (2.3) is starting...\033[0m"
	cd /usr/game/cores/channel2/core3/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (3.3) is starting...\033[0m"
	cd /usr/game/cores/channel3/core1/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (3.2) is starting...\033[0m"
	cd /usr/game/cores/channel3/core2/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (3.3) is starting...\033[0m"
	cd /usr/game/cores/channel3/core3/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (99) is starting ...\033[0m"
	cd /usr/game/cores/channel99/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel 3 is Live!\033[0m"
	
	
;;
4*)

	echo -e "\033[1;32mDatabase is starting...\033[0m"
	cd /usr/game/cores/db/
	sh run.sh
	sleep 2
	clear
	echo -e "\033[1;32m \nAuth is starting...\033[0m"
	cd /usr/game/cores/auth/
	sh run.sh
	sleep 2
	clear
	echo -e "\033[1;32m \nChannel (1.1) is starting...\033[0m"
	cd /usr/game/cores/channel1/core1/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (1.2) is starting...\033[0m"
	cd /usr/game/cores/channel1/core2/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (1.3) is starting...\033[0m"
	cd /usr/game/cores/channel1/core3/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (2.1) is starting...\033[0m"
	cd /usr/game/cores/channel2/core1/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (2.2) is starting...\033[0m"
	cd /usr/game/cores/channel2/core2/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (2.3) is starting...\033[0m"
	cd /usr/game/cores/channel2/core3/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (3.1) is starting...\033[0m"
	cd /usr/game/cores/channel3/core1/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (3.2) is starting...\033[0m"
	cd /usr/game/cores/channel3/core2/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (3.3) is starting...\033[0m"
	cd /usr/game/cores/channel3/core3/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (4.1) is starting...\033[0m"
	cd /usr/game/cores/channel4/core1/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (4.2) is starting...\033[0m"
	cd /usr/game/cores/channel4/core2/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (4.3) is starting...\033[0m"
	cd /usr/game/cores/channel4/core3/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (99) is starting ...\033[0m"
	cd /usr/game/cores/channel99/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel 4 is Live!\033[0m"


;;
5*)	

	echo -e "\033[1;32mDatabase is starting...\033[0m"
	cd /usr/game/cores/db/
	sh run.sh
	sleep 2
	clear
	echo -e "\033[1;32m \nAuth is Starting...\033[0m"
	cd /usr/game/cores/auth/
	sh run.sh
	sleep 2
	clear
	echo -e "\033[1;32m \nChannel (1.1) is starting...\033[0m"
	cd /usr/game/cores/channel1/core1/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (1.2) is starting...\033[0m"
	cd /usr/game/cores/channel1/core2/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (1.3) is starting...\033[0m"
	cd /usr/game/cores/channel1/core3/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (2.1) is starting...\033[0m"
	cd /usr/game/cores/channel2/core1/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (2.2) is starting...\033[0m"
	cd /usr/game/cores/channel2/core2/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (2.3) is starting...\033[0m"
	cd /usr/game/cores/channel2/core3/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (3.1) is starting...\033[0m"
	cd /usr/game/cores/channel3/core1/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (3.2) is starting...\033[0m"
	cd /usr/game/cores/channel3/core2/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (3.3) is starting...\033[0m"
	cd /usr/game/cores/channel3/core3/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (4.1) is starting...\033[0m"
	cd /usr/game/cores/channel4/core1/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (4.2) is starting...\033[0m"
	cd /usr/game/cores/channel4/core2/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (4.3) is starting...\033[0m"
	cd /usr/game/cores/channel4/core3/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (5.1) is starting...\033[0m"
	cd /usr/game/cores/channel5/core1/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (5.2) is starting...\033[0m"
	cd /usr/game/cores/channel5/core2/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (5.3) is starting...\033[0m"
	cd /usr/game/cores/channel5/core3/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (99) is starting...\033[0m"
	cd /usr/game/cores/channel99/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel 5 is Live!\033[0m"
	
;;
6*)

	echo -e "\033[1;32mDatabase is starting...\033[0m"
	cd /usr/game/cores/db/
	./db &
	sleep 2
	clear
	echo -e "\033[1;32m \nAuth is starting...\033[0m"
	cd /usr/game/cores/auth/
	sh run.sh
	sleep 2
	clear
	echo -e "\033[1;32m \nChannel (1.1) is starting...\033[0m"
	cd /usr/game/cores/channel1/core1/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (1.2) is starting...\033[0m"
	cd /usr/game/cores/channel1/core2/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (1.3) is starting...\033[0m"
	cd /usr/game/cores/channel1/core3/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (2.1) is starting...\033[0m"
	cd /usr/game/cores/channel2/core1/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (2.2) is starting...\033[0m"
	cd /usr/game/cores/channel2/core2/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (2.3) is starting...\033[0m"
	cd /usr/game/cores/channel2/core3/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (3.1) is starting...\033[0m"
	cd /usr/game/cores/channel3/core1/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (3.2) is starting...\033[0m"
	cd /usr/game/cores/channel3/core2/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (3.3) is starting...\033[0m"
	cd /usr/game/cores/channel3/core3/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (4.1) is starting...\033[0m"
	cd /usr/game/cores/channel4/core1/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (4.2) is starting...\033[0m"
	cd /usr/game/cores/channel4/core2/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (4.3) is starting...\033[0m"
	cd /usr/game/cores/channel4/core3/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (5.1) is starting...\033[0m"
	cd /usr/game/cores/channel5/core1/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (5.2) is starting...\033[0m"
	cd /usr/game/cores/channel5/core2/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (5.3) is starting...\033[0m"
	cd /usr/game/cores/channel5/core3/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (6.1) is starting...\033[0m"
	cd /usr/game/cores/channel6/core1/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (6.2) is starting...\033[0m"
	cd /usr/game/cores/channel6/core2/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (6.3) is starting...\033[0m"
	cd /usr/game/cores/channel6/core3/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel (99) is starting ...\033[0m"
	cd /usr/game/cores/channel99/
	sh run.sh
	sleep 2
	echo -e "\033[1;32m \nChannel 6 is Live!\033[0m"

;;
esac
