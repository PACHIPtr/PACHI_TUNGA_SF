ROOT=$PWD

sleep 1
echo "Closing Auth"
# Shutdown auth
cd $ROOT/cores/auth && sh shut.sh
sleep 1
# Shutdown channel1
echo "Channel (1.1) is closing."
cd $ROOT/cores/channel1/core1 && sh shut.sh
sleep 1
echo "Channel (1.2) is closing."
cd $ROOT/cores/channel1/core2 && sh shut.sh
sleep 1
echo "Channel (1.3) is closing."
cd $ROOT/cores/channel1/core3 && sh shut.sh
sleep 1
# Shutdown channel2
echo "Channel (2.1) is closing."
cd $ROOT/cores/channel2/core1 && sh shut.sh
sleep 1
echo "Channel (2.2) is closing."
cd $ROOT/cores/channel2/core2 && sh shut.sh
sleep 1
echo "Channel (2.3) is closing."
cd $ROOT/cores/channel2/core3 && sh shut.sh
sleep 1
# Shutdown channel3
echo "Channel (3.1) is closing."
cd $ROOT/cores/channel3/core1 && sh shut.sh
sleep 1
echo "Channel (3.2) is closing."
cd $ROOT/cores/channel3/core2 && sh shut.sh
sleep 1
echo "Channel (3.3) is closing."
cd $ROOT/cores/channel3/core3 && sh shut.sh
sleep 1
# Shutdown channel4
echo "Channel (4.1) is closing."
cd $ROOT/cores/channel4/core1 && sh shut.sh
sleep 1
echo "Channel (4.2) is closing."
cd $ROOT/cores/channel4/core2 && sh shut.sh
sleep 1
echo "Channel (4.3) is closing."
cd $ROOT/cores/channel4/core3 && sh shut.sh
sleep 1
# Shutdown channel5
echo "Channel (5.1) is closing."
cd $ROOT/cores/channel5/core1 && sh shut.sh
sleep 1
echo "Channel (5.2) is closing."
cd $ROOT/cores/channel5/core2 && sh shut.sh
sleep 1
echo "Channel (5.3) is closing."
cd $ROOT/cores/channel5/core3 && sh shut.sh
sleep 1
# Shutdown channel6
echo "Channel (6.1) is closing."
cd $ROOT/cores/channel6/core1 && sh shut.sh
sleep 1
echo "Channel (6.2) is closing."
cd $ROOT/cores/channel6/core2 && sh shut.sh
sleep 1
echo "Channel (6.3) is closing."
cd $ROOT/cores/channel6/core3 && sh shut.sh
sleep 1
# Shutdown channel99
echo "Channel (99) is closing."
cd $ROOT/cores/channel99 && sh shut.sh
sleep 1
# Shutdown db
echo "Database is closing."
cd $ROOT/cores/db && sh shut.sh
sleep 2

